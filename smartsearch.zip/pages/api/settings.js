import { pool } from "../../lib/db";
import { verifyToken } from "../../lib/auth";

// GET = citește setări, POST = salvează setări
export default async function handler(req, res) {
  // Găsește userul autentificat din cookie
  const cookie = req.headers.cookie || "";
  const match = cookie.match(/token=([^;]+)/);
  if (!match) return res.status(401).json({ error: "Neautentificat" });

  const user = verifyToken(match[1]);
  if (!user) return res.status(401).json({ error: "Token invalid" });

  if (req.method === "GET") {
    try {
      const [rows] = await pool.query("SELECT settings FROM settings WHERE user_id = ?", [user.id]);
      if (!rows.length) {
        // Nimic salvat încă pentru acest user
        return res.status(200).json({ settings: null });
      }
      res.status(200).json({ settings: rows[0].settings });
    } catch (err) {
      res.status(500).json({ error: "Eroare la citire setări." });
    }
  } else if (req.method === "POST") {
    const { settings } = req.body;
    if (!settings || typeof settings !== "object") {
      return res.status(400).json({ error: "Setări lipsă sau invalide" });
    }
    try {
      // Încearcă UPDATE, dacă nu există facem INSERT
      const [exist] = await pool.query("SELECT id FROM settings WHERE user_id = ?", [user.id]);
      if (exist.length) {
        await pool.query("UPDATE settings SET settings = ? WHERE user_id = ?", [JSON.stringify(settings), user.id]);
      } else {
        await pool.query("INSERT INTO settings (user_id, settings) VALUES (?, ?)", [user.id, JSON.stringify(settings)]);
      }
      res.status(200).json({ ok: true });
    } catch (err) {
      res.status(500).json({ error: "Eroare la salvare setări." });
    }
  } else {
    res.setHeader("Allow", ["GET", "POST"]);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
