// pages/api/settings/get.js
import { pool } from "../../../lib/db";
import { verifyToken } from "../../../lib/auth";

export default async function handler(req, res) {
  const cookie = req.headers.cookie || "";
  const match = cookie.match(/token=([^;]+)/);
  if (!match) return res.status(401).json({ error: "Neautorizat" });
  const payload = verifyToken(match[1]);
  if (!payload) return res.status(401).json({ error: "Token invalid" });
  const user_id = payload.id;

  // Products
  const [[prodEndpoint]] = await pool.query("SELECT endpoint FROM products_endpoint WHERE user_id=?", [user_id]);
  const [[prodSettings]] = await pool.query("SELECT result_limit, default_timeout FROM products_settings WHERE user_id=?", [user_id]);

  // AI
  const [[ai]] = await pool.query("SELECT * FROM ai_settings WHERE user_id=?", [user_id]);

  // UI
  const [[ui]] = await pool.query("SELECT * FROM ui_settings WHERE user_id=?", [user_id]);

  // Templates
  const [[tpl]] = await pool.query("SELECT * FROM template_product_card WHERE user_id=?", [user_id]);

  // Fallback
  const [[fb]] = await pool.query("SELECT * FROM fallback_settings WHERE user_id=?", [user_id]);

  res.json({
    products: {
      endpoint: prodEndpoint?.endpoint || "",
      resultLimit: prodSettings?.result_limit || 5,
      defaultTimeout: prodSettings?.default_timeout || 10000
      // similarWords separat!
    },
    ai: ai || {},
    ui: ui || {},
    templates: tpl ? {
      productCard: {
        template: tpl.template,
        styles: {
          containerStyle: tpl.container_style,
          leftStyle: tpl.left_style,
          imgStyle: tpl.img_style,
          rightStyle: tpl.right_style,
          categoryStyle: tpl.category_style,
          titleStyle: tpl.title_style,
          descriptionStyle: tpl.description_style,
          footerStyle: tpl.footer_style,
          priceStyle: tpl.price_style,
          buttonStyle: tpl.button_style
        }
      }
    } : {},
    fallback: fb ? {
      notFound: fb.not_found,
      notFoundSingle: fb.not_found_single,
      error: fb.error_message
    } : {}
  });
}
