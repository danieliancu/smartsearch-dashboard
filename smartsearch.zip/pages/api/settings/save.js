// pages/api/settings/save.js
import { pool } from "../../../lib/db";
import { verifyToken } from "../../../lib/auth";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const cookie = req.headers.cookie || "";
  const match = cookie.match(/token=([^;]+)/);
  if (!match) return res.status(401).json({ error: "Neautorizat" });

  const payload = verifyToken(match[1]);
  if (!payload) return res.status(401).json({ error: "Token invalid" });
  const user_id = payload.id;

  const { products, ai, ui, templates, fallback } = req.body;

  // PRODUCTS ENDPOINT & LIMITS
  if (products) {
    if (products.endpoint) {
      await pool.query(
        "INSERT INTO products_endpoint (user_id, endpoint) VALUES (?, ?) ON DUPLICATE KEY UPDATE endpoint=?",
        [user_id, products.endpoint, products.endpoint]
      );
    }
    await pool.query(
      "INSERT INTO products_settings (user_id, result_limit, default_timeout) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE result_limit=?, default_timeout=?",
      [user_id, products.resultLimit, products.defaultTimeout, products.resultLimit, products.defaultTimeout]
    );
    // similarWords nu se salvează aici!
  }

  // AI
  if (ai) {
    await pool.query(
      `INSERT INTO ai_settings (user_id, model, explanation_model, system_prompt, explanation_prompt) 
       VALUES (?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE model=?, explanation_model=?, system_prompt=?, explanation_prompt=?`,
      [
        user_id, ai.model, ai.explanationModel, ai.systemPrompt, ai.explanationPrompt,
        ai.model, ai.explanationModel, ai.systemPrompt, ai.explanationPrompt
      ]
    );
  }

  // UI
  if (ui) {
    await pool.query(
      `INSERT INTO ui_settings (user_id, language, app_title, input_placeholder, send_button_text)
       VALUES (?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE language=?, app_title=?, input_placeholder=?, send_button_text=?`,
      [
        user_id, ui.language, ui.appTitle, ui.inputPlaceholder, ui.sendButtonText,
        ui.language, ui.appTitle, ui.inputPlaceholder, ui.sendButtonText
      ]
    );
  }

  // TEMPLATE
  if (templates?.productCard) {
    const s = templates.productCard.styles;
    await pool.query(
      `INSERT INTO template_product_card (user_id, template, container_style, left_style, img_style, right_style, category_style, title_style, description_style, footer_style, price_style, button_style)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE template=?, container_style=?, left_style=?, img_style=?, right_style=?, category_style=?, title_style=?, description_style=?, footer_style=?, price_style=?, button_style=?`,
      [
        user_id, templates.productCard.template,
        s.containerStyle, s.leftStyle, s.imgStyle, s.rightStyle, s.categoryStyle, s.titleStyle, s.descriptionStyle, s.footerStyle, s.priceStyle, s.buttonStyle,
        templates.productCard.template,
        s.containerStyle, s.leftStyle, s.imgStyle, s.rightStyle, s.categoryStyle, s.titleStyle, s.descriptionStyle, s.footerStyle, s.priceStyle, s.buttonStyle
      ]
    );
  }

  // FALLBACK
  if (fallback) {
    await pool.query(
      `INSERT INTO fallback_settings (user_id, not_found, not_found_single, error_message)
       VALUES (?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE not_found=?, not_found_single=?, error_message=?`,
      [
        user_id, fallback.notFound, fallback.notFoundSingle, fallback.error,
        fallback.notFound, fallback.notFoundSingle, fallback.error
      ]
    );
  }

  res.json({ ok: true });
}
