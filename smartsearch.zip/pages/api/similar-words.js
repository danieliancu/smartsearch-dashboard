// pages/api/similar-words.js
import { pool } from "../../lib/db";
import { verifyToken } from "../../lib/auth";

export default async function handler(req, res) {
  const cookie = req.headers.cookie || "";
  const match = cookie.match(/token=([^;]+)/);
  if (!match) return res.status(401).json({ error: "Neautorizat" });
  const payload = verifyToken(match[1]);
  if (!payload) return res.status(401).json({ error: "Token invalid" });
  const user_id = payload.id;

  if (req.method === "GET") {
    const [rows] = await pool.query("SELECT main_word, synonym FROM products_similar_words WHERE user_id=?", [user_id]);
    const result = {};
    rows.forEach(({ main_word, synonym }) => {
      if (!result[main_word]) result[main_word] = [];
      result[main_word].push(synonym);
    });
    return res.json(result);
  }

  if (req.method === "POST") {
    const data = req.body; // JSON {main_word: [syn1, syn2, ...]}
    await pool.query("DELETE FROM products_similar_words WHERE user_id=?", [user_id]);
    const values = [];
    Object.entries(data).forEach(([main, arr]) => {
      arr.forEach(syn => values.push([user_id, main, syn]));
    });
    if (values.length)
      await pool.query(
        "INSERT INTO products_similar_words (user_id, main_word, synonym) VALUES ?",
        [values]
      );
    return res.json({ ok: true });
  }

  res.status(405).end();
}
